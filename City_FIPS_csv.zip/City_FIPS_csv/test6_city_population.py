import re
import csv

LApath='/Users/mahannan/Audia/Pictia/LAdata.csv'
CApath='/Users/mahannan/Audia/Pictia/CAdata.csv'

#finalcsv=open(csvpath, "r")
#finalcsv.write("city, Mar27 confirmed, Mar27 heat, Mar26 confirmed, Mar26 heat, Mar25 confirmed, Mar25 heat, Mar24 confirmed, Mar24 heat, Mar23 confirmed, Mar23 heat, Mar22 confirmed, Mar22 heat, Mar21 confirmed, Mar21 heat, Mar20 confirmed, Mar20 heat, Mar19 confirmed, Mar19 heat, Mar18 confirmed, Mar18 heat, Mar17 confirmed, Mar17 heat,\n")
#finalcsv.close()
#finalreader=csv.DictReader(finalcsv)
#for row in finalreader:
match=0
idx=0
with open(LApath) as LAfile:
	LAreader=csv.DictReader(LAfile)
	outputpath='/Users/mahannan/Audia/Pictia/output.csv'
	finaloutput=open(outputpath, "w")
	outputwriter=csv.DictWriter(finaloutput,fieldnames=LAreader.fieldnames)	
	for LArow in LAreader:
		idx=idx+1
		#if(idx<2):continue
		#LA row city,population
		#print LArow
		LAname=LArow['city']
		LAname=LAname.replace(' ', '')
		LAname=LAname.lower()
		#LApopu=LArow['population']
		with open(CApath) as CAfile:
			CAreader = csv.DictReader(CAfile)
			for CArow in CAreader:
				#CA row name,Summary Level,State Code,County Code,Place Code
				#print CArow
				CAname=CArow['name']
				CAname=CAname.replace(' ', '')
				CAname=CAname.lower()
				find=0
				if (CAname.find(LAname) != -1): find=1
				if (LAname.find(CAname) != -1): find=1
				if (find>0):
					#LApopu=LArow['population']
					LArow['Summary Level']=CArow['Summary Level']
					LArow['State Code']=CArow['State Code']
					LArow['County Code']=CArow['County Code']
					LArow['Place Code']=CArow['Place Code']
		outputwriter.writerow(LArow)


